

package analizador;

/** CUP generated class containing symbol constants. */
public class sym {
  /* terminals */
  public static final int Else = 7;
  public static final int Parentesis_c = 22;
  public static final int For = 10;
  public static final int Parentesis_a = 21;
  public static final int Suma = 12;
  public static final int Numero = 30;
  public static final int Corchete_c = 26;
  public static final int Op_booleano = 20;
  public static final int ERROR = 33;
  public static final int Corchete_a = 25;
  public static final int Identificador = 29;
  public static final int Comillas = 3;
  public static final int Resto = 32;
  public static final int Llave_c = 24;
  public static final int Coma = 31;
  public static final int Llave_a = 23;
  public static final int Op_relacional = 17;
  public static final int P_coma = 28;
  public static final int T_dato = 4;
  public static final int Main = 27;
  public static final int Cadena = 5;
  public static final int EOF = 0;
  public static final int Division = 15;
  public static final int Op_incremento = 19;
  public static final int Op_atribucion = 18;
  public static final int Resta = 13;
  public static final int If = 6;
  public static final int Linea = 2;
  public static final int error = 1;
  public static final int Op_logico = 16;
  public static final int Do = 8;
  public static final int Igual = 11;
  public static final int While = 9;
  public static final int Multiplicacion = 14;
}

